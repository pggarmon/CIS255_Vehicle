
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VehicleSelection extends JFrame {
    private JComboBox<String> makeComboBox;
    private JComboBox<String> modelComboBox;
    private JComboBox<String> typeComboBox;

    private String[] makes = {"Chevrolet", "Ford", "Honda", "Hyundai", "Toyota"};

    private String[][] models = {
            {"Camero", "Corvette"},
            {"Mustang", "Taurus", "Fusion"},
            {"Civic", "Accord", "CR-Z"},
            {"Veloster", "Genesis", "Elantra", "IONIQ", "Sonata", "Accent", "Kona", "Tucson", "SantaFe", "Palisade", "SantaCruz"},
            {"86", "GR", "Camry", "Corolla", "Avalon", "Sonic", "Malibu", "Cruze", "Equinox", "Tahoe", "Blazer", "TrailBlaze", "Traverse", "Silverado", "Colorado", "Bronco", "Explorer", "Expedition", "Escape", "F150", "Maverick", "Ranger", "Clarity", "Insight", "Passport", "CR-V", "HR-V", "Ridgeline", "Elantra", "bZ4X", "Rav4", "4runner", "Venza", "Highlander", "Tacoma", "Tundra"}
    };

    private String[] types = {"Coupe", "Sedan", "Truck", "SUV"};

    public VehicleSelection() {
        setTitle("Car Selection");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new FlowLayout());

        makeComboBox = new JComboBox<>(makes);
        modelComboBox = new JComboBox<>(models[0]);
        typeComboBox = new JComboBox<>(types);

        makeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = makeComboBox.getSelectedIndex();
                modelComboBox.setModel(new DefaultComboBoxModel<>(models[selectedIndex]));
            }
        });

        add(new JLabel("Make:"));
        add(makeComboBox);
        add(new JLabel("Model:"));
        add(modelComboBox);
        add(new JLabel("Type:"));
        add(typeComboBox);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VehicleSelection();
            }
        });
    }
}